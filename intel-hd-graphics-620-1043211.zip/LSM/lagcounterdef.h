#ifndef _OFFSETS_H
#define _OFFSETS_H


#define PROCESS_DELAY             0
#define SESSION_DELAY             2
#define PROCESS_DELAY_CTR         4
#define SESSION_DELAY_CTR         6

#define LAST_DELAY_COUNTER_OFFSET SESSION_DELAY_CTR

#endif