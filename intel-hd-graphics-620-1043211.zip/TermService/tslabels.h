/* (C) 1997-1998 Microsoft Corp.
 *
 * tslabels.h
 *
 * PerfMon Lodctr utility offsets for TS perf objects.
 */

// TS defined counter names and explain text defines
#define WINSTATION_OBJECT             0

#define LAST_WINSTATION_COUNTER_OFFSET WINSTATION_OBJECT

